#ifndef COMMAND_TEST_H
#define COMMAND_TEST_H

#include "command.h"
#include "test.h"

void test_command_ini();

/******************************************************************************/

void test_command_interpretInput();

/******************************************************************************/

void test_command_getOb();

/******************************************************************************/

void test_command_getOb2();

/******************************************************************************/

void test_command_getVrb();

/******************************************************************************/

void test_command_getType();

#endif
