#ifndef INV_TEST_H
#define INV_TEST_H

void test1_inv_create();

void test2_inv_create();

void test3_inv_create();

void test4_inv_create();

/*-----------------------------------------------------------------*/

void test1_inv_add();

void test2_inv_add();

void test3_inv_add();

void test4_inv_add();

void test5_inv_add();

void test6_inv_add();

void test7_inv_add();

/*-----------------------------------------------------------------*/

void test1_inv_remove();

void test2_inv_remove();

void test3_inv_remove();

void test4_inv_remove();

/*-----------------------------------------------------------------*/

void test1_inv_full();

void test2_inv_full();

void test3_inv_full();

void test4_inv_full();

#endif
