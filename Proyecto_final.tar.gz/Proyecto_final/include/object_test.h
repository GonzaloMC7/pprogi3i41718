#ifndef OBJECT_TEST_H
#define OBJECT_TEST_H


/*-----------------------------------------------------------------*/
void test1_object_create();
void test2_object_create();
/*-----------------------------------------------------------------*/
void test1_object_destroy();
void test2_object_destroy();
void test3_object_destroy();
/*-----------------------------------------------------------------*/
void test1_object_setname();
void test2_object_setname();
void test3_object_setname();
/*-----------------------------------------------------------------*/
void test1_object_getname();
void test2_object_getname();
/*-----------------------------------------------------------------*/
void test1_object_getid();
void test2_object_getid();
/*-----------------------------------------------------------------*/
void test1_object_setdescription();
void test2_object_setdescription();
void test3_object_setdescription();
/*-----------------------------------------------------------------*/
void test1_object_getdescription();
void test2_object_getdescription();
/*-----------------------------------------------------------------*/
void test1_object_setid();
void test2_object_setid();
void test3_object_setid();
/*-----------------------------------------------------------------*/
void test1_object_setmovable();
void test2_object_setmovable();
/*-----------------------------------------------------------------*/
void test1_object_setmoved();
void test2_object_setmoved();
/*-----------------------------------------------------------------*/
void test1_object_sethidden();
void test2_object_sethidden();
/*-----------------------------------------------------------------*/
void test1_object_setkey();
void test2_object_setkey();
void test3_object_setkey();
/*-----------------------------------------------------------------*/
void test1_object_setlight();
void test2_object_setlight();
/*-----------------------------------------------------------------*/
void test1_object_seton();
void test2_object_seton();
/*-----------------------------------------------------------------*/
void test1_object_getmovable();
void test2_object_getmovable();
/*-----------------------------------------------------------------*/
void test1_object_getmoved();
void test2_object_getmoved();
/*-----------------------------------------------------------------*/
void test1_object_gethidden();
void test2_object_gethidden();
/*-----------------------------------------------------------------*/
void test1_object_getkey();
void test2_object_getkey();
/*-----------------------------------------------------------------*/
void test1_object_getlight();
void test2_object_getlight();
/*-----------------------------------------------------------------*/
void test1_object_geton();
void test2_object_geton();

#endif
