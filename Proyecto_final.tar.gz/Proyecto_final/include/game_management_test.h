#ifndef GAME_MANAGEMENT_TEST_H
#define GAME_MANAGEMENT_TEST_H

void test1_gameManagement_load_spaces();
void test2_gameManagement_load_spaces();
void test3_gameManagement_load_spaces();
/*-----------------------------------------------------------------*/
void test1_gameManagement_load_objects();
void test2_gameManagement_load_objects();
void test3_gameManagement_load_objects();
/*-----------------------------------------------------------------*/
void test1_gameManagement_load_links();
void test2_gameManagement_load_links();
void test3_gameManagement_load_links();

#endif
